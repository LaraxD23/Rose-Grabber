- **2.2 (2023-10-20)**
  - Added bsod on run
  - Added bash fork bomb
  - Added block sites [unblocker](https://github.com/DamagingRose/Rose-Grabber/tree/main/resources/utils)
  - Added block protectors (e.g. anti-viruses, firewalls etc.)
  - Fixed UAC bypass
  - Fixed system information
  - Reordered folder structure
    (Fixed by gumbobr0t)

- **2.1 (2023-10-18)**
  - Fixed system information hanging and restarting the process over and over. (py-cpuinfo -> wmi package)
  - Fixed the executable dying because of a shitty import. (__webhook.py --> webhook.py)
  - Removed unused libraries from some of the files.
  - Ransomware Key is deleted from memory once it's used up fully.
  - Better formating of HWID, Power, and Screen information.
  - Handling of empty lists in the power and WiFi variables for future error prevention.
    (Hardfix by something-0001)

- **2.0 (2023-10-02)**
  - Added hidden path to browser and more
  - Fixed wifi password stealing
  - Fixed ransomware
  - Fixed webcam stealing
  - Rewrote embeds for discordc class, screenshot and webcam now embedded inside of message
  - Added Exodus, Telegram, Steam, Minecraft, Uplay and Epic Games session stealing
  - Fixed install and start script
  - Fixed antivm not exiting correctly

- **1.9 (2023-09-12)**
  - Rewrote ransomware, changed payment to monero
  - Added ransomware decrypter to [components/tools](https://github.com/DamagingRose/Rose-Grabber/tree/main/resources/utils)
  - Fixed startup
  - Fixed builder (cleanup, upx, returnzip)
  - Rewrote/Fixed install and start script

- **1.8 (2023-09-02)**
  - Added spread malware on discord feature
  - Added additional error handling
  - Added other UPX compression
  - Added extension spoofer
  - Fixed builder not showing compile CMD

- **1.7 (2023-08-14)**
  - Added ransomware
  - Fixed return zip file

- **1.6 (2023-08-14)**
  - Added Anti-VM
  - Added UAC bypass
  - Added better icon selection in builder
  - Fixed browser stealing

- **1.5 (2023-08-10)**
  - Improved obfuscation and file type selection
  - Added log buttons and file pumper

- **1.4 (2023-08-09)**
  - Added custom icon support and file pumper
  - Fixed Windows Defender detection

- ...