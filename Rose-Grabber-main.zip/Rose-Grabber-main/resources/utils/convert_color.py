color = "#FC4DDC"
color_as_int = int(color[1:], 16)
print(color_as_int)
